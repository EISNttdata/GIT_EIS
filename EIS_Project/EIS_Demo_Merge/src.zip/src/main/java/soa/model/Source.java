package soa.model;

public interface Source
  extends IEndpoint
{}
