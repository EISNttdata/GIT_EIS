package soa.model;

interface IEndpoint
{
  String getUri();
}
