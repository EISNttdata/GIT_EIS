package soa.model;

public interface Target
  extends IEndpoint
{}
