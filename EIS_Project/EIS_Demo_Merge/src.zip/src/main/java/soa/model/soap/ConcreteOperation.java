package soa.model.soap;

/**
 * Created by Manoj_Mehta on 3/28/2017.
 */
public abstract class ConcreteOperation {}
