package soa.output;

abstract interface IEndpoint
{
  public abstract String getUri();
}
