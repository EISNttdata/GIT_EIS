package soa.output;

public abstract interface Target
  extends IEndpoint
{}
