package soa.output;

import soa.output.wsdl.WSDLGenerator;

/**
 * Created by Manoj_Mehta on 4/7/2017.
 */
public class JCAGenerator extends WSDLGenerator
{

}
