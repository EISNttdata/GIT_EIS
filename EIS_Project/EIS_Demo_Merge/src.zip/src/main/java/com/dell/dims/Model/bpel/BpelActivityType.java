package com.dell.dims.Model.bpel;

/**
 * Created by Pramod_Kumar_Tyagi on 8/1/2017.
 */
public enum BpelActivityType {

  SCOPE,SEQUENCE,ASSIGN,ACTIVITY,REPLY

}
