package com.dell.dims.Builder;

import com.dell.dims.Model.Activity;

/**
 * Created by Manoj_Mehta on 7/17/2017.
 */
public class ForEachBuilder  extends AbstractActivityBuilder {
    @Override
    public void build(Activity activity) throws Exception
    {

        //
    }
}
