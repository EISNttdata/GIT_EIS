package com.dell.dims.gop;

/**
 * @author pramod
 */
public interface Graphicable {
    void graph();
}
