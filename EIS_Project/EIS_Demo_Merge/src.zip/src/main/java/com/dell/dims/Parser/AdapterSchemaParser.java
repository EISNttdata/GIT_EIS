
package com.dell.dims.Parser;

import com.dell.dims.Model.AdapterSchemaModel;

public class AdapterSchemaParser
{
    public AdapterSchemaModel parse(String fileName) throws Exception {
        return new AdapterSchemaModel();
    }

}


// TODO
