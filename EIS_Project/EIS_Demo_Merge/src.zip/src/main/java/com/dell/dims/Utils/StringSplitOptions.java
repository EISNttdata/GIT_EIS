package com.dell.dims.Utils;

/**
 * Created by Manoj_Mehta on 1/4/2017.
 */
public enum StringSplitOptions {
    None,
    RemoveEmptyEntries;

    StringSplitOptions() {
    }
}
