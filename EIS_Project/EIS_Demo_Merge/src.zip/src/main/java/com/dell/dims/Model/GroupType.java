

package com.dell.dims.Model;


public enum GroupType
{
    INPUTLOOP,
    SIMPLEGROUP,
    REPEAT,
    CRITICALSECTION,
    WHILE,
    ERRORLOOP
}

