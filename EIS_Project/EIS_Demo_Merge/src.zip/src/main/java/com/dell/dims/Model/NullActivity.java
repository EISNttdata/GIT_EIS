package com.dell.dims.Model;

/**
 * Created by Kriti_Kanodia on 1/16/2017.
 */
public class NullActivity extends Activity {

    public NullActivity (String name, ActivityType type) throws Exception {
        super(name, type);
    }

    public NullActivity() throws Exception {
    }
}
