package com.dell.dims.Builder;

import com.dell.dims.Model.Activity;

/**
 * Created by Manoj_Mehta on 5/18/2017.
 */
public class ConfirmActivityBuilder extends AbstractActivityBuilder {
    @Override
    public void build(Activity activity) {

    }

}
