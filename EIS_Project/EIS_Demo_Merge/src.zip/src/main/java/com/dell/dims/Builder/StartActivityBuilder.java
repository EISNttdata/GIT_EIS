package com.dell.dims.Builder;


import com.dell.dims.Model.Activity;

public class StartActivityBuilder extends AbstractActivityBuilder
{

    @Override
    public void build(Activity activity) {

        System.out.println("SOA Start ACtivity com.dell.dims.Builder");

    }
}


